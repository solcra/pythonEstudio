from calculos_generales.calculos_generales import dividir, redondear

var = dividir(5,2)
redondear(var)