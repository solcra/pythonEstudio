def sumar(op1,op2):
  resultado = op1 + op2
  print("EL resultado de la suma es: ",resultado)
  return resultado

def restar(op1,op2):
  resultado = op1 - op2
  print("EL resultado de la resta es: ", resultado)
  return resultado

def multiplicaicon(op1,op2):
  resultado = op1 * op2
  print("EL resultado de la multiplicacion es: ",resultado)
  return resultado

def dividir(op1,op2):
  resultado = op1 / op2
  print("EL resultado de la divicion es: ",resultado)
  return resultado

def potencia(op1,op2):
  resultado = op1 ** op2
  print("EL resultado de la potencia es: ",resultado)
  return resultado

def redondear(op1):
  resultado = round(op1)
  print("EL resultado numero redondiado es: ",resultado )
  return resultado